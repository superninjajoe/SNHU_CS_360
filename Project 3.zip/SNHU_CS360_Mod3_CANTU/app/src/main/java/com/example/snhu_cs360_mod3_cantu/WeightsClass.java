package com.example.snhu_cs360_mod3_cantu;

public class WeightsClass {

    private final int ID;
    private final String date;
    private final float weight;

    public WeightsClass(int ID, String date, float weight) {
        this.ID = ID;
        this.date = date;
        this.weight = weight;
    }

    public String getDate() {
        return date;
    }

    public float getWeight() {
        return weight;
    }

    public int getID() {return ID;}

}
