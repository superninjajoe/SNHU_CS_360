package com.example.snhu_cs360_mod3_cantu;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDB extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "users.db";
    private static UserDB _UserDB;

    //make the constructor private since this will be a singleton
    private UserDB(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    //singleton
    public static UserDB getInstance(Context context) {
        if (_UserDB == null) {
            _UserDB = new UserDB(context);
        }
        return _UserDB;
    }

    @Override
    public void onCreate(SQLiteDatabase _db) {
        _db.execSQL("create Table users(username TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase _db, int oldVersion, int newVersion) {
        _db.execSQL("drop Table if exists users");
    }

    //if username doesn't exist create it with password

    //delete all users
    public void deleteUser(UserModel _user){
        SQLiteDatabase _db = this.getWritableDatabase();
        _db.delete("users", "username = ?", new String[]{_user.getUserName()} );
    }
}
