package com.example.snhu_cs360_mod3_cantu;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class WeightDB extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "weights.db";
    private static WeightDB _weightDB;

    //make the constructor private since this will be a singleton
    private WeightDB(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    //singleton
    public static WeightDB getInstance(Context context) {
        if (_weightDB == null) {
            _weightDB = new WeightDB(context);
        }
        return _weightDB;
    }

    @Override
    public void onCreate(SQLiteDatabase _db) {
        //create the user's weight diary
        _db.execSQL("create Table weights(_ID INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, date text, weight float)");

        //create the goals per user
        _db.execSQL("create Table goals(username TEXT primary key, goal float)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase _db, int oldVersion, int newVersion) {
        _db.execSQL("drop Table if exists weights");
        _db.execSQL("drop Table if exists goals");
    }

    public void removeEntry(Integer entryID){
        SQLiteDatabase _db = this.getWritableDatabase();
        _db.delete("weights","_id = ?",new String[]{String.valueOf(entryID)});
    }

    public void updateEntry(float weight, UserModel _user){
        ContentValues values= new ContentValues();

        values.put("username", _user.getUserName());
        values.put("weight", weight);

    }


    @SuppressLint({"SimpleDateFormat", "WeekBasedYear"})
    public List<WeightsClass> getAllWeights(UserModel _user) {

        List<WeightsClass> allEntry = new ArrayList<>();
        SQLiteDatabase _db = this.getWritableDatabase();

        Cursor cursor = _db.rawQuery("SELECT * FROM weights ORDER BY date", null);

        if(cursor.moveToFirst()){
            do {
                //get the username from the db entry
                String username = cursor.getString(1);

                //if the username matches the user logged in then start the loop
                if (username.equals(_user.getUserName())){

                    int ID = cursor.getInt(0);
                    String date = cursor.getString(2);

                    //change the date from ISO to mm-dd-yyyy
                    @SuppressLint("SimpleDateFormat") SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    Date newDate;
                    String prettyDate = null;
                    try {
                        newDate = format.parse(date);
                        format = new SimpleDateFormat("MM-dd-yyyy");
                        prettyDate = format.format(newDate);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    int userWeight = cursor.getInt(3);

                    //use the constructor to make objects
                    //add the objects to the list
                    WeightsClass newEntry = new WeightsClass(ID, prettyDate, userWeight);
                    allEntry.add(newEntry);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return allEntry;
    }

    public void deleteUser(UserModel _user){
        SQLiteDatabase _db = this.getWritableDatabase();

        _db.delete("goals", "username = ?", new String[]{_user.getUserName()} );
        _db.delete("weights", "username = ?", new String[]{_user.getUserName()} );
    }
}