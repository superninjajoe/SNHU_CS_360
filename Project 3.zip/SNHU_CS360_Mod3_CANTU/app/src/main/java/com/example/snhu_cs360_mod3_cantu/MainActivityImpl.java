package com.example.snhu_cs360_mod3_cantu;

public class MainActivityImpl extends MainActivity {
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
}
