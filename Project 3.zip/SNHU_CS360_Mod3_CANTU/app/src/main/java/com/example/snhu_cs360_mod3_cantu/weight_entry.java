package com.example.snhu_cs360_mod3_cantu;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;


public class weight_entry extends AppCompatActivity {

    protected EditText dateEntry;
    protected EditText weightEntry;
    protected String isoDate;
    UserModel _user;
    WeightDB _db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_entry);

        dateEntry = findViewById(R.id.editWeightDate);
        weightEntry = findViewById(R.id.editWeightWeight);

        _user = UserModel.getUserInstance();
        _db = WeightDB.getInstance(this);

        dateEntry.setOnClickListener(v -> {
            // on below line we are getting
            // the instance of our calendar.
            final Calendar c = Calendar.getInstance();

            // on below line we are getting
            // our day, month and year.
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            // on below line we are creating a variable for date picker dialog.
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    // on below line we are passing context.
                    weight_entry.this,
                    new DatePickerDialog.OnDateSetListener() {
                        @SuppressLint("SetTextI18n")
                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {
                            // on below line we are setting date to our edit text.
                            dateEntry.setText((monthOfYear + 1) + "-" + dayOfMonth  + "-" + year);
                            isoDate = year + "-" + (monthOfYear + 1) + "-" +
                                    dayOfMonth;
                        }
                    },
                    // on below line we are passing year,
                    // month and day for selected date in our date picker.
                    year, month, day);
            // at last we are calling show to
            // display our date picker dialog.
            datePickerDialog.show();
        });
    }

    public void openMainForm(View view){
        Intent intent = new Intent(this, main_screen.class);
        startActivity(intent);
    }
    public void onSaveClick(View view){
        String date = dateEntry.getText().toString();
        String sWeight = weightEntry.getText().toString();
        float weight;

        //protect against an empty form
        if (!date.isEmpty() && !sWeight.isEmpty()){
            weight = Float.parseFloat(sWeight);

            //did the user just reach their goal?
            //if so do they have SMS on?
            //If yes then send the message
            if(weight <= _user.getGoal()){
                if(_user.isTextPermission()){
                    Object SMSNotifications = null;
                    SMSNotifications.getClass()
                }
            }
        }

        //go back to main
        Intent intent = new Intent(this, main_screen.class);
        startActivity(intent);

    }
}